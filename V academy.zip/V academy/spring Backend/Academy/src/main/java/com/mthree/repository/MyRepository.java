package com.mthree.repository;

import java.util.List;

import javax.transaction.Transactional;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Modifying;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import com.mthree.entity.Course;
import com.mthree.entity.CourseModel;
import com.mthree.entity.User;

@Repository
public interface MyRepository extends JpaRepository<User,Integer> {

	 @Query(value="insert into user(user_name,user_password) values(:user_name,:user_password) ",nativeQuery=true)
	    @Modifying
	    @Transactional
	    public void addUsers(@Param("user_name") String userName,
	                         @Param("user_password") String userpassword);
	 
	 @Query(value="select * from user where user_name=:user_name ",nativeQuery=true)
	 @Transactional
	 public User getPassword(@Param("user_name") String userName);
	 
	 	@Query(value="select * from course",nativeQuery=true)
	    @Transactional
	    List<Object> getAllCourse();
	 	
	 	 @Query(value="insert into course(course_topic,course_url,course_desc) values(:course_topic,:course_url,:course_desc) ",nativeQuery=true)
		    @Modifying
		    @Transactional
	 	 public void addCourse(@Param("course_topic") String topic,
                 @Param("course_url") String url,
                 @Param("course_desc") String desc);
	 	
}
