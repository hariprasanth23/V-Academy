package com.mthree.entity;

public class CourseModel {
	private String topic;
	private String url;
	private String desc;
	
	public CourseModel() {}
	public CourseModel(String topic, String url, String desc) {
		super();
		this.topic = topic;
		this.url = url;
		this.desc = desc;
	}
	public String getTopic() {
		return topic;
	}
	public void setTopic(String topic) {
		this.topic = topic;
	}
	public String getUrl() {
		return url;
	}
	public void setUrl(String url) {
		this.url = url;
	}
	public String getDesc() {
		return desc;
	}
	public void setDesc(String desc) {
		this.desc = desc;
	}
	@Override
	public String toString() {
		return "CourseModel [topic=" + topic + ", url=" + url + ", desc=" + desc + "]";
	}
	

}
