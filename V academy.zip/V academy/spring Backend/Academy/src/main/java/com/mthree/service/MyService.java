package com.mthree.service;

import java.util.*;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import com.mthree.entity.Course;
import com.mthree.entity.CourseModel;
import com.mthree.entity.User;
import com.mthree.repository.MyRepository;

@Service
public class MyService {
	@Autowired
	MyRepository myRepository;
	
	public void register(String userName,String userPassword) {
		myRepository.addUsers(userName, userPassword);
	}
	public User login(String userName) {
		return myRepository.getPassword(userName);
	}

	public List<Object> getAllCourse() {
		return	(List<Object>) myRepository.getAllCourse();
		 
	}
	public void addCourse(String topic,String url,String desc) {
		myRepository.addCourse(topic, url, desc);
	}

}
