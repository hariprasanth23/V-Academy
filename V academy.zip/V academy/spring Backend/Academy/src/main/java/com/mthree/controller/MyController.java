package com.mthree.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import com.mthree.entity.Course;
import com.mthree.entity.CourseModel;
import com.mthree.entity.Register;
import com.mthree.entity.User;
import com.mthree.service.MyService;

@RestController
@CrossOrigin(origins = "*")
public class MyController {
	@Autowired
	MyService myService;
	
	@PostMapping(value="/register")
    public ResponseEntity register(@RequestBody Register register){
        myService.register(register.getName(),register.getPassword());
        return ResponseEntity.ok("Successfully Registered");
    }
	
	@PostMapping(value="/login")
    public ResponseEntity login(@RequestBody Register register){
        User u=myService.login(register.getName());
        String status="";
       
        if(u!=null)
        {
        	String password=u.getPassword();
        	 if(password.equals(register.getPassword())) {
         		status="Logged In Successfully";
         	}else {
         		status="Password Incorrect";
         	}
        }else {
        	status="User Doesn't exists..kindly Register";
        }
        return ResponseEntity.ok(status);
    }

	@GetMapping(value="/course")
    public ResponseEntity getCourse(){
        List<Object> course=(List<Object>)myService.getAllCourse();
         return ResponseEntity.ok().body(course);
    }
	@PostMapping(value="/addcourse")
	public ResponseEntity addCourse(@RequestBody CourseModel courseModel) {
		myService.addCourse(courseModel.getTopic(),courseModel.getUrl(),courseModel.getDesc());
        return ResponseEntity.ok("Added successfully");
	}
	
	
}
