package com.mthree.entity;

import javax.annotation.Generated;
import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.Table;

import com.fasterxml.jackson.annotation.JsonBackReference;

@Entity
@Table(name="course")
public class Course {
	
	@Id
	@GeneratedValue(strategy=GenerationType.AUTO)
	@Column(name="course_id")
	private int id;
	
	@Column(name="course_topic")
	private String topic;
	
	@Column(name="course_url")
	private String url;
	
	@Column(name="course_desc")
	private String desc;
	
	
	@ManyToOne(cascade = CascadeType.ALL)
    @JoinColumn(name="user_id", referencedColumnName = "user_id")
    private User username;
	
	public Course() {}

	public Course(String topic, String url, String desc, User username) {
		super();
		this.topic = topic;
		this.url = url;
		this.desc = desc;
		this.username = username;
	}

	@Override
	public String toString() {
		return "Course [topic=" + topic + ", url=" + url + ", desc=" + desc + ", username=" + username + "]";
	}

	public String getTopic() {
		return topic;
	}

	public void setTopic(String topic) {
		this.topic = topic;
	}

	public String getUrl() {
		return url;
	}

	public void setUrl(String url) {
		this.url = url;
	}

	public String getDesc() {
		return desc;
	}

	public void setDesc(String desc) {
		this.desc = desc;
	}

	public User getUsername() {
		return username;
	}

	public void setUsername(User username) {
		this.username = username;
	}
	
	

}
