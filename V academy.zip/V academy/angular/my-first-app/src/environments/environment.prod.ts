export const environment = {
  production: true,
  firebaseAPIKey:'AIzaSyDyT114Du0gWMerBhw3C4vAjwpobPlq8MI'
};
