import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-course-start',
  templateUrl: './course-start.component.html',
  styleUrls: ['./course-start.component.css']
})
export class CourseStartComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
