import { Injectable } from '@angular/core';
import {
  Resolve,
  ActivatedRouteSnapshot,
  RouterStateSnapshot
} from '@angular/router';

import { Course } from './course.model';
import { DataStorageService } from '../shared/data-storage.service';
import { CourseService } from './course.service';

@Injectable({ providedIn: 'root' })
export class CoursesResolverService implements Resolve<Course[]> {
  constructor(
    private dataStorageService: DataStorageService,
    private coursesService: CourseService
  ) {}

  resolve(route: ActivatedRouteSnapshot, state: RouterStateSnapshot) {
    const courses = this.coursesService.getCourses();

    if (courses.length === 0) {
      return this.dataStorageService.fetchCourses();
    } else {
      return courses;
    }
  }
}
