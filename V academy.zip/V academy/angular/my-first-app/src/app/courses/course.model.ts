import { Topic } from '../shared/topic.model';

export class Course {
  public name: string;
  public description: string;
  public imagePath: string;
  public topics: Topic[];

  constructor(name: string, desc: string, imagePath: string, topics: Topic[]) {
    this.name = name;
    this.description = desc;
    this.imagePath = imagePath;
    this.topics = topics;
  }
}
