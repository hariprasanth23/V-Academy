import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';

import { CoursesComponent } from './courses.component';
import { AuthGuard } from '../auth/auth.guard';
import { CourseStartComponent } from './course-start/course-start.component';
import { CourseEditComponent } from './course-edit/course-edit.component';
import { CourseDetailComponent } from './course-detail/course-detail.component';
import { CoursesResolverService } from './courses-resolver.service';

const routes: Routes = [
  {
    path: '',
    component: CoursesComponent,
    canActivate: [AuthGuard],
    children: [
      { path: '', component: CourseStartComponent },
      { path: 'new', component: CourseEditComponent },
      {
        path: ':id',
        component: CourseDetailComponent,
        resolve: [CoursesResolverService]
      },
      {
        path: ':id/edit',
        component: CourseEditComponent,
        resolve: [CoursesResolverService]
      }
    ]
  }
];

@NgModule({
  imports: [RouterModule.forChild(routes)],
  exports: [RouterModule]
})
export class CoursesRoutingModule {}
