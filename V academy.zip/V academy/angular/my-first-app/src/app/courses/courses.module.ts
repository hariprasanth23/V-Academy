import { NgModule } from '@angular/core';
import { RouterModule } from '@angular/router';
import { ReactiveFormsModule } from '@angular/forms';

import { CoursesComponent } from './courses.component';
import { CourseListComponent } from './course-list/course-list.component';
import { CourseDetailComponent } from './course-detail/course-detail.component';
import { CourseItemComponent } from './course-list/course-item/course-item.component';
import { CourseStartComponent } from './course-start/course-start.component';
import { CourseEditComponent } from './course-edit/course-edit.component';
import { CoursesRoutingModule } from './courses-routing.module';
import { SharedModule } from '../shared/shared.module';

@NgModule({
  declarations: [
    CoursesComponent,
    CourseListComponent,
    CourseDetailComponent,
    CourseItemComponent,
    CourseStartComponent,
    CourseEditComponent
  ],
  imports: [
    RouterModule,
    ReactiveFormsModule,
    CoursesRoutingModule,
    SharedModule
  ]
})
export class CoursesModule {
}
