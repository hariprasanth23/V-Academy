import { Injectable } from '@angular/core';
import { Subject } from 'rxjs';

import { Course } from './course.model';
import { Topic } from '../shared/topic.model';
import { AllCoursesService } from '../all-courses/all-courses.service';

@Injectable()
export class CourseService {
  coursesChanged = new Subject<Course[]>();

  private courses: Course[] = [];

  constructor(private slService: AllCoursesService) {}

  setCourses(courses: Course[]) {
    this.courses = courses;
    this.coursesChanged.next(this.courses.slice());
  }

  getCourses() {
    return this.courses.slice();
  }

  getCourse(index: number) {
    return this.courses[index];
  }

  addTopicsToAllCourses(topics: Topic[]) {
    this.slService.addTopics(topics);
  }

  addCourse(course: Course) {
    this.courses.push(course);
    this.coursesChanged.next(this.courses.slice());
  }

  updateCourse(index: number, newCourse: Course) {
    this.courses[index] = newCourse;
    this.coursesChanged.next(this.courses.slice());
  }

  deleteCourse(index: number) {
    this.courses.splice(index, 1);
    this.coursesChanged.next(this.courses.slice());
  }
}
