import { Component, OnInit } from '@angular/core';
import { ActivatedRoute, Params, Router } from '@angular/router';
import { FormGroup, FormControl, FormArray, Validators } from '@angular/forms';

import { CourseService } from '../course.service';

@Component({
  selector: 'app-course-edit',
  templateUrl: './course-edit.component.html',
  styleUrls: ['./course-edit.component.css']
})
export class CourseEditComponent implements OnInit {
  id: number;
  editMode = false;
  courseForm: FormGroup;

  get topicsControls() {
    return (this.courseForm.get('topics') as FormArray).controls;
  }

  constructor(
    private route: ActivatedRoute,
    private courseService: CourseService,
    private router: Router
  ) {}

  ngOnInit() {
    this.route.params.subscribe((params: Params) => {
      this.id = +params['id'];
      this.editMode = params['id'] != null;
      this.initForm();
    });
  }

  onSubmit() {
    // const newCourse = new Course(
    //   this.courseForm.value['name'],
    //   this.courseForm.value['description'],
    //   this.courseForm.value['imagePath'],
    //   this.courseForm.value['topics']);
    if (this.editMode) {
      this.courseService.updateCourse(this.id, this.courseForm.value);
    } else {
      this.courseService.addCourse(this.courseForm.value);
    }
    this.onCancel();
  }

  onAddTopic() {
    (<FormArray>this.courseForm.get('topics')).push(
      new FormGroup({
        name: new FormControl(null, Validators.required),
        amount: new FormControl(null, [
          Validators.required,
          Validators.pattern(/^[1-9]+[0-9]*$/)
        ])
      })
    );
  }

  onDeleteTopic(index: number) {
    (<FormArray>this.courseForm.get('topics')).removeAt(index);
  }

  onCancel() {
    this.router.navigate(['../'], { relativeTo: this.route });
  }

  private initForm() {
    let courseName = '';
    let courseImagePath = '';
    let courseDescription = '';
    let courseTopics = new FormArray([]);

    if (this.editMode) {
      const course = this.courseService.getCourse(this.id);
      courseName = course.name;
      courseImagePath = course.imagePath;
      courseDescription = course.description;
      if (course['topics']) {
        for (let topic of course.topics) {
          courseTopics.push(
            new FormGroup({
              name: new FormControl(topic.name, Validators.required),
              amount: new FormControl(topic.amount, [
                Validators.required,
                Validators.pattern(/^[1-9]+[0-9]*$/)
              ])
            })
          );
        }
      }
    }

    this.courseForm = new FormGroup({
      name: new FormControl(courseName, Validators.required),
      imagePath: new FormControl(courseImagePath, Validators.required),
      description: new FormControl(courseDescription, Validators.required),
      topics: courseTopics
    });
  }
}
