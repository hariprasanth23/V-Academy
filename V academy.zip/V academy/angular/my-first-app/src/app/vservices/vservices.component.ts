import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-vservices',
  templateUrl: './vservices.component.html',
  styleUrls: ['./vservices.component.css']
})
export class VservicesComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
