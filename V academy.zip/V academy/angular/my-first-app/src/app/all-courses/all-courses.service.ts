import { Topic} from '../shared/topic.model';
import { Subject } from 'rxjs';

export class AllCoursesService {
  topicsChanged = new Subject<Topic[]>();
  startedEditing = new Subject<number>();
  private topics: Topic[] = [
    new Topic('SpringBoot', 5),
    new Topic('AngularJS', 10),
  ];

  getTopics() {
    return this.topics.slice();
  }

  getTopic(index: number)
  {
    return this.topics[index];
  }

  addTopic(topic: Topic) {
    this.topics.push(topic);
    this.topicsChanged.next(this.topics.slice());
  }

  addTopics(topics: Topic[]) {
    this.topics.push(...topics);
    this.topicsChanged.next(this.topics.slice());
  }

  updateTopic(index: number, newTopic: Topic) {
    this.topics[index] = newTopic;
    this.topicsChanged.next(this.topics.slice());
  }

  deleteTopic(index: number) {
    this.topics.splice(index, 1);
    this.topicsChanged.next(this.topics.slice());
  }
}