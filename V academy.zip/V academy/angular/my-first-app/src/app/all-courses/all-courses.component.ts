import { Component, OnInit, OnDestroy } from '@angular/core';
import { Subscription } from 'rxjs';

import { Topic } from '../shared/topic.model'; 
import { AllCoursesService }from './all-courses.service';
import { LoggingService } from '../logging.service';

@Component({
  selector: 'app-all-courses',
  templateUrl: './all-courses.component.html',
  styleUrls: ['./all-courses.component.css']
})
export class AllCoursesComponent implements OnInit, OnDestroy {
   
  topics : Topic[];
  private subscription: Subscription;

  constructor(private acService:AllCoursesService,
    private loggingService: LoggingService) { }

  ngOnInit() {
    this.topics = this.acService.getTopics();
    this.subscription = this.acService.topicsChanged.subscribe(
      (topics: Topic[]) => {
        this.topics = topics;
      }
    );

    this.loggingService.printLog('Hello from AllCoursesComponent ngOnInit!');
  }

  onEditItem(index: number) {
    this.acService.startedEditing.next(index);
  }

  ngOnDestroy() {
    this.subscription.unsubscribe();
  }
   
}
