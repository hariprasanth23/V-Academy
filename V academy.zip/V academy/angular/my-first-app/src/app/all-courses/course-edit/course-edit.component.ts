import {
  Component,
  OnInit,
  ElementRef,
  ViewChild
} from '@angular/core';

import { NgForm } from '@angular/forms';
import { Subscription } from 'rxjs';

import { Topic } from '../../shared/topic.model';
import { AllCoursesService } from '../all-courses.service';

@Component({
  selector: 'app-course-edit',
  templateUrl: './course-edit.component.html',
  styleUrls: ['./course-edit.component.css']
})
export class CourseEditComponent implements OnInit {
  @ViewChild('f', { static: false }) acForm: NgForm;
  subscription: Subscription;
  editMode = false;
  editedItemIndex: number;
  editedItem: Topic;

  constructor(private acService: AllCoursesService) { }

  ngOnInit() {
    this.subscription = this.acService.startedEditing
      .subscribe(
        (index: number) => {
          this.editedItemIndex = index;
          this.editMode = true;
          this.editedItem = this.acService.getTopic(index);
          this.acForm.setValue({
            name: this.editedItem.name,
            amount: this.editedItem.amount
          })
        }
      );
  }

  onSubmit(form: NgForm) {
    const value = form.value;
    const newTopic = new Topic(value.name, value.amount);
    if (this.editMode) {
      this.acService.updateTopic(this.editedItemIndex, newTopic);
    } else {
      this.acService.addTopic(newTopic);
    }
    this.editMode = false;
    form.reset();
  }

  onClear() {
    this.acForm.reset();
    this.editMode = false;
  }

  onDelete() {
    this.acService.deleteTopic(this.editedItemIndex);
    this.onClear();
  }

  ngOnDestroy() {
    this.subscription.unsubscribe();
  }

}