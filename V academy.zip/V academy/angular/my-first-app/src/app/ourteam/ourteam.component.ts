import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-ourteam', 
  templateUrl: './ourteam.component.html',
  styleUrls: ['./ourteam.component.css']
})
export class OurteamComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}


