import { Injectable } from '@angular/core';
import { HttpClient, HttpParams } from '@angular/common/http';
import { map, tap, take, exhaustMap } from 'rxjs/operators';

import { Course } from '../courses/course.model';
import { CourseService } from '../courses/course.service';
import { AuthService } from '../auth/auth.service';

@Injectable({ providedIn: 'root' })
export class DataStorageService {
  constructor(
    private http: HttpClient,
    private courseService: CourseService,
    private authService: AuthService
  ) {}

  storeCourses() {
    const courses = this.courseService.getCourses();
    this.http
      .put(
        'https://ng-course-v-academy.firebaseio.com/courses.json',
        courses
      )
      .subscribe(response => {
        console.log(response);
      });
  }

  fetchCourses() {
    return this.http
      .get<Course[]>(
        'https://ng-course-v-academy.firebaseio.com/courses.json'
      )
      .pipe(
        map(courses => {
          return courses.map(course => {
            return {
              ...course,
              topics: course.topics ? course.topics : []
            };
          });
        }),
        tap(courses => {
          this.courseService.setCourses(courses);
        })
      );
  }
}
