export class Topic
{
  constructor(public name:string,public amount:number)
  {
      
  }
  
}